import React, { useEffect, useState } from "react";
import axios from "axios";
import { Modal, Button, Form } from "react-bootstrap";

function StudentList() {
  const [students, setStudents] = useState([]);

  // Add
  const [show, setShow] = useState(false); // State to handle modal visibility
  const [newStudent, setNewStudent] = useState({
    studentID: "",
    name: "",
    email: "",
    unit: "",
    grades: "",
  });
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // delete
  const [showDelete, setDeleteShow] = useState(false);
  const handleDeleteClose = () => setDeleteShow(false);
  const handleDeleteShow = () => setDeleteShow(true);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewStudent((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:4200/students", newStudent)
      .then((response) => {
        setStudents([...students, response.data]); // Assuming your backend returns the added student
        handleClose(); // Close the modal
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    // Adjust the URL to match your server's address and port
    axios
      .get("http://localhost:4200/students")
      .then((response) => {
        setStudents(response.data);
      })
      .catch((error) => console.log(error));
  }, []);

  // Update

  const [showUpdate, setShowUpdate] = useState(false); // To show/hide the update modal
  const [selectedStudent, setSelectedStudent] = useState(null); // To store the selected student for update

  const handleShowUpdate = (student) => {
    setSelectedStudent({ ...student }); // Copy the student object to form
    setShowUpdate(true);
  };

  const handleUpdateSubmit = (e) => {
    e.preventDefault();
    axios
      .put(
        `http://localhost:4200/students/${selectedStudent.studentID}`,
        selectedStudent
      )
      .then((response) => {
        // Update UI accordingly...
        setShowUpdate(false); // Hide the update modal
      })
      .catch((error) => console.error(error));
  };

  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState(null);

  const handleDeleteConfirm = (studentID) => {
    setStudentToDelete(studentID);
    setShowConfirmationModal(true);
  };

  const handleDelete = () => {
    // Perform the delete operation using studentToDelete
    axios
      .delete(`http://localhost:4200/students/${studentToDelete}`)
      .then(() => {
        setShowConfirmationModal(false);
        // Update your state to remove the deleted student
        setStudents(
          students.filter((student) => student.studentID !== studentToDelete)
        );
      })
      .catch((error) => console.error("Error deleting student:", error));
  };

  function confirm() {}

  return (
    <div className="container mt-5">
      <h2>Student List</h2>
      <Button variant="primary" onClick={handleShow}>
        Add New Student
      </Button>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Student</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            {/* Form fields */}
            <Form.Group>
              <Form.Label>Student ID</Form.Label>
              <Form.Control
                type="text"
                name="studentID"
                required
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                required
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                name="email"
                required
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Unit</Form.Label>
              <Form.Control
                type="text"
                name="unit"
                required
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Grades</Form.Label>
              <Form.Control
                type="text"
                name="grades"
                required
                onChange={handleChange}
              />
            </Form.Group>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="primary" type="submit">
              Save Changes
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
      {/* update */}
      <Modal show={showUpdate} onHide={() => setShowUpdate(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Update Student</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleUpdateSubmit}>
            <Form.Group>
              <Form.Label>Student ID</Form.Label>
              <Form.Control
                type="text"
                readOnly
                value={selectedStudent?.studentID}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                required
                value={selectedStudent?.name}
                onChange={(e) =>
                  setSelectedStudent({
                    ...selectedStudent,
                    name: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                name="email"
                required
                value={selectedStudent?.email}
                onChange={(e) =>
                  setSelectedStudent({
                    ...selectedStudent,
                    email: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Unit</Form.Label>
              <Form.Control
                type="text"
                name="unit"
                required
                value={selectedStudent?.unit}
                onChange={(e) =>
                  setSelectedStudent({
                    ...selectedStudent,
                    unit: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Grades</Form.Label>
              <Form.Control
                type="text"
                name="grades"
                required
                value={selectedStudent?.grades}
                onChange={(e) =>
                  setSelectedStudent({
                    ...selectedStudent,
                    grades: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Button variant="secondary" onClick={() => setShowUpdate(false)}>
              Close
            </Button>
            <Button variant="primary" type="submit">
              Update
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
      `{" "}
      <Modal
        show={showConfirmationModal}
        onHide={() => setShowConfirmationModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>Are you sure you want to delete this student?</Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => setShowConfirmationModal(false)}
          >
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
      <table className="table">
        <thead>
          <tr>
            <th>Student ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Unit</th>
            <th>Grades</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.studentID}>
              <td>{student.studentID}</td>
              <td>{student.name}</td>
              <td>{student.email}</td>
              <td>{student.unit}</td>
              <td>{student.grades}</td>
              <td>
                {/* <Button variant="danger" onClick={handleShow}>Delete</Button> */}
                <button
                  className="btn btn-warning m-1"
                  onClick={() => handleShowUpdate(student)}
                >
                  Update
                </button>
                <button
                  className="btn btn-danger m-1"
                  onClick={() => handleDeleteConfirm(student.studentID)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentList;

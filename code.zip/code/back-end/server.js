const express = require('express');
const fs = require('fs');

const app = express();
const PORT = 4200;
const cors = require('cors');
app.use(cors());


app.use(express.json());

app.get('/students', (req, res) => {
    fs.readFile('data.json', (err, data) => {
      if (err) {
        res.status(500).send('Error reading data file');
        return;
      }
      res.setHeader('Content-Type', 'application/json');
      res.send(data);
    });
  });


  app.post('/students', (req, res) => {
    // Step 1: Read the current data from the file
    fs.readFile('data.json', (err, data) => {
        if (err) {
            res.status(500).send('Error reading data file');
            return;
        }
        let students = JSON.parse(data);

        // Step 2: Add the new student data to the array
        students.push(req.body); // Assuming the body contains a student object

        // Step 3: Write the updated array back to the file
        fs.writeFile('data.json', JSON.stringify(students, null, 2), (err) => {
            if (err) {
                res.status(500).send('Error writing data to file');
                return;
            }
            res.status(201).send('Student added');
        });
    });
});


app.delete('/students/:studentID', (req, res) => {
    const studentID = req.params.studentID;

    fs.readFile('data.json', 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error reading data file');
            return;
        }

        let students = JSON.parse(data);
        const filteredStudents = students.filter(student => student.studentID !== studentID);

        if (students.length === filteredStudents.length) {
            res.status(404).send('Student not found');
            return;
        }

        fs.writeFile('data.json', JSON.stringify(filteredStudents, null, 2), (err) => {
            if (err) {
                res.status(500).send('Error writing data to file');
                return;
            }
            res.status(200).send('Student deleted');
        });
    });
});

app.put('/students/:studentID', (req, res) => {
    const studentID = req.params.studentID;
    const updatedStudentInfo = req.body;

    fs.readFile('data.json', 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error reading data file');
            return;
        }

        let students = JSON.parse(data);
        let studentFound = false;

        const updatedStudents = students.map(student => {
            if (student.studentID === studentID) {
                studentFound = true;
                return { ...student, ...updatedStudentInfo };
            }
            return student;
        });

        if (!studentFound) {
            res.status(404).send('Student not found');
            return;
        }

        fs.writeFile('data.json', JSON.stringify(updatedStudents, null, 2), (err) => {
            if (err) {
                res.status(500).send('Error writing data to file');
                return;
            }
            res.status(200).send('Student updated');
        });
    });
});


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
